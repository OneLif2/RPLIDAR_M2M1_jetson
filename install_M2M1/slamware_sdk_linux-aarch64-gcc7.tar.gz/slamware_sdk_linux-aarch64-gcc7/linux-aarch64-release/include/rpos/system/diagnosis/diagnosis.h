/*
* diagnosis.h
* Diagnose facilities
*
* Created by Tony Huang (tony@slamtec.com) at 2016-6-14
* Copyright 2016 (c) Shanghai Slamtec Co., ltd.
*/

#pragma once

#include "diagnosis_serialization.h"
#include "test_logging_store.h"
#include "message_write_stream.h"
