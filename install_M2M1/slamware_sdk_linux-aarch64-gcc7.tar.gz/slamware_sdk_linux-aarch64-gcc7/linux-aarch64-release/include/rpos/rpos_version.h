#pragma once

#define  RPOS_VERSION_MAJOR       2
#define  RPOS_VERSION_MINOR       8
#define  RPOS_VERSION_REVISION    3
#define  RPOS_VERSION_SUFFIX      "rtm"
#define  RPOS_VERSION_SHORT       "2.8"
#define  RPOS_VERSION_LONG        "2.8.3"
#define  RPOS_VERSION_FULL        "2.8.3-rtm"
#define  RPOS_COMMIT              "commit:3763a35"
