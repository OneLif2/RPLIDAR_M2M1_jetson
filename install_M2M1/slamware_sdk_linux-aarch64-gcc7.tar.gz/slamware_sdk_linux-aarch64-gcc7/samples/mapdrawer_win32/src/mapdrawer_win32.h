// mapdrawer_win32.h
